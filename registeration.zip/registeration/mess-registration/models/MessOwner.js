const mongoose = require('mongoose');

const MessOwnerSchema = new mongoose.Schema({
    messName: String,
    ownerName: String,
    email: { type: String, unique: true },
    password: String,
    address: String,
    mobile: String,
    description: String,
    imageUrl: String
});

module.exports = mongoose.model('MessOwner', MessOwnerSchema);
