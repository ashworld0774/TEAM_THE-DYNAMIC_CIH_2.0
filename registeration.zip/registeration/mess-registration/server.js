const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const bodyParser = require('body-parser');
const path = require('path');
const MessOwner = require('./models/MessOwner');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

mongoose.connect('mongodb://127.0.0.1:27017/messInfo', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => console.log("MongoDB Connected"))
  .catch(err => console.log(err));

// Serve registration page
app.get('/register', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'register.html'));
});

// Handle registration
app.post('/register', async (req, res) => {
    const { messName, ownerName, email, password, address, mobile } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    
    try {
        const messOwner = new MessOwner({
            messName,
            ownerName,
            email,
            password: hashedPassword,
            address,
            mobile
        });

        await messOwner.save();
        res.redirect('/start.html');
    } catch (error) {
        res.send('Error during registration: ' + error.message);
    }
});

app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});

// Handle editing mess info
app.post('/edit', async (req, res) => {
    const { email, description, imageUrl } = req.body;

    try {
        await MessOwner.findOneAndUpdate({ email }, {
            description,
            imageUrl
        });

        res.send('Mess info updated! <a href="/start.html">Back to Dashboard</a>');
    } catch (err) {
        res.send('Error updating: ' + err.message);
    }
});
